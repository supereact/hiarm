FlameRobin
---------------------------
FlameRobin is a software package for administration of Firebird DBMS. It is
developed by:

* Milan Babuskov
* Nando Dessena
* Michael Hieke
* Gregory Sapunkov
* Bart Bakker
* Marius Popa


The following people also made a significant non-coding contributions:

* Alex Stanciu
* Barbara Del Vecchio

License
---------------------------
FlameRobin code is licensed under the MIT license.
A copy of the license can be found in the [LICENSE](https://github.com/mariuz/flamerobin/blob/master/LICENSE) file

Part of code covering IBPP library is licensed under IBPP license.
A copy of IBPP license can be found in src/ibpp folder.

Some icons are licensed under LGPL license.
A copy of LGPL license can be found in res folder.
