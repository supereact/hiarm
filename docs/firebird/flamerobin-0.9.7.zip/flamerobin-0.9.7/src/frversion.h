#define FR_VERSION_MAJOR    0
#define FR_VERSION_MINOR    9
#define FR_VERSION_RLS      7

// if this file can't be found you need to run the update-revision-info script
#include "revisioninfo.h"
