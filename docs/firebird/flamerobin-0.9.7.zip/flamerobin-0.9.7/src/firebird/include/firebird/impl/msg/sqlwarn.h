FB_IMPL_MSG_NO_SYMBOL(SQLWARN, 100, "Row not found for fetch, update or delete, or the result of a query is an empty table.")
FB_IMPL_MSG_NO_SYMBOL(SQLWARN, 101, "segment buffer length shorter than expected")
FB_IMPL_MSG_NO_SYMBOL(SQLWARN, 301, "Datatype needs modification")
FB_IMPL_MSG_NO_SYMBOL(SQLWARN, 612, "Duplicate column or domain name found.")
